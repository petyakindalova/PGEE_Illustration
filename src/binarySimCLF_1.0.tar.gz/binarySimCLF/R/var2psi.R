`var2psi` <-
function(v, mu)
{
  return ( cor2psi(var2cor(v), mu) )
}

