`blrchk` <-
function(u, V)
{
  B <- allReg(V);
  return( blrchk1(u,B) );
}

